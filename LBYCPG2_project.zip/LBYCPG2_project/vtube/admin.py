from django.contrib import admin
from vtube.models import vtuber


# Register your models here.
@admin.register(vtuber)
class VtubeAdmin(admin.ModelAdmin):
    list_display = ['name', 'Ddate', 'tag_list']

    def tag_list(self, obj):
        return u", ".join(o.name for o in obj.tags.all())
