from django.urls import path
from . import views
from .views import PostDetail,  PostListView


urlpatterns = [
    path('', views.PostListView.as_view(), name='index'),
    path('<slug:slug>/', views.PostDetail.as_view(), name='about'),
    path('tags/<slug:tag_slug>/', views.TagIndexView.as_view(), name='posts_by_tag'),
]
