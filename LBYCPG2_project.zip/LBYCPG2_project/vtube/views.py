from django.shortcuts import render
from taggit.models import Tag
from vtube.models import vtuber
from django.views import generic
from django.views.generic.list import ListView
from .models import *

# Create your views here.
class TagMixin(object):
          def get_context_data(self, **kwargs):
              context = super(TagMixin, self).get_context_data(**kwargs)
              context['tags'] = Tag.objects.all()
              return context
    
class PostListView(TagMixin, ListView):
    model = vtuber
    template_name = 'test.html'
    queryset=vtuber.objects.all()
    context_object_name = 'vt'
    
class TagIndexView(TagMixin,ListView):
    model = vtuber
    template_name = 'test.html'
    context_object_name = 'posts'

    def get_queryset(self):
        return vtuber.objects.filter(tags__slug=self.kwargs.get('tag_slug'))

class PostDetail(generic.DetailView):
    model = vtuber
    template_name = 'info.html'

